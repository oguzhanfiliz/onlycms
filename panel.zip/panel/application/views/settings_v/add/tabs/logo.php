<div role="tabpanel" class="tab-pane fade" id="tab-7">

    <div class="row">

        <div class="form-group col-md-6">
            <label>Görsel Seçiniz</label>
            <input type="file" name="logo" class="form-control">
        </div>

    </div>

</div><!-- .tab-pane  -->